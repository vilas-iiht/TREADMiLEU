
public class Manager extends Employee{
	
	private double comm;

	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Manager(int empno, String name, double sal,double comm) {
		super(empno,name,sal);
		this.comm=comm;
		// TODO Auto-generated constructor stub
	}	
	
	@Override
	public String toString() {
		return super.toString()+" Comm="+comm;
	}

	public double getComm() {
		return comm;
	}
	

}
