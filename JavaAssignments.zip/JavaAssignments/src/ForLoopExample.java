import java.util.Scanner;

public class ForLoopExample {

	public static void main(String[] args) {
        int num, number, temp, total = 0;
        System.out.println("�nter 3 Digit Number");
        Scanner scanner = new Scanner(System.in);
        num = scanner.nextInt();
        //
        number = num; //123
        while(number!=0)
        {
            temp = number % 10;
            total = total + temp;
            number /= 10;
        }
        if(total == num)
            System.out.println(num + " is an Pali number");
        else
            System.out.println(num + " is not an Pali number");
        
        scanner.close();
    }

}
