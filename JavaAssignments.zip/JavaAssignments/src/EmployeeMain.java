
public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1=new Employee();
		e1.setEmpno(101);
		e1.setName("Ram");
		e1.setSal(40000);
		System.out.println(e1.toString());
	}

}
