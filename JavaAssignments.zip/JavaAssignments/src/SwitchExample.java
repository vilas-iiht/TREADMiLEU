
public class SwitchExample {
	
	public static void main(String[] args) {
		
		int x,y,z;
		int choice;
		x=20;
		y=30;
		
		choice=2;
		switch(choice)
		{
		case 1:
			System.out.println("Sum Is "+(x+y));
			break;
		case 2:
			System.out.println("Sub Is "+(x-y));
			break;	
		default:
			System.out.println("Wrong Choice");
		
		
		}
		
	}

}
