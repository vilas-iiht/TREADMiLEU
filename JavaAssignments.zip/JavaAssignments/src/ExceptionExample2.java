import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ExceptionExample2 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub		
		next();

	}
	
	public static void next() throws IOException 
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		try {
			String str=br.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
			
		}
		
		System.out.println("Next Finished");
	}
	
	

}
