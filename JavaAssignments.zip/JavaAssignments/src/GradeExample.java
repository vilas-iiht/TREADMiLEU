
public class GradeExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Per>=75->dist,Per>=60->First,Per>=45->Sec,else fail
		int per=67;
		if(per>=75 && per<=100) {
			System.out.println("Dist");			
		}
		else if(per>=60)
			System.out.println("First");
		else if(per>=45)
			System.out.println("Sec");
		else
			System.out.println("Fail");
			
			

	}

}
