
public class Employee {
	
	private int empno;
	private String name;
	private double sal;
	private static int noOfObjectSCreated;
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	
	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", name=" + name + ", sal=" + sal + "]";
	}
	
	//this or super
	public Employee(int empno, String name, double sal) {
		super();
		this.empno = empno;
		this.name = name;
		this.sal = sal;
	}
	
	//this or super
		public Employee(int empno, String name) {
			super();
			this.empno = empno;
			this.name = name;
			
		}
	
	public Employee(String name, double sal) {
		super();
		this.empno = ++noOfObjectSCreated;
		this.name = name;
		this.sal = sal;
	}
	public Employee() {
		this(0,"Unknown",0);		
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}
