
public class OuterInnerMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OuterClass outerClass=new OuterClass();
		//OuterClass.InnerClass innerClass= outerClass.new InnerClass();//Inner Class
		OuterClass.InnerClass innerClass= new OuterClass.InnerClass();//Ststic Inner
		innerClass.display();

	}

}
