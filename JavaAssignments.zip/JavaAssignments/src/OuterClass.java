class BaseClass
{
	private int x=40;
	//BaseClass Class Display Function
		public void display()
		{
			System.out.println("BaseClass Class x="+x);
		}
}
public class OuterClass {

	private int x=20;
	
	public static class InnerClass extends BaseClass
	{
		private int x=30;
		//Inner Class Display Function
		public void display()
		{
			InnerClass.super.display();
			//OuterClass.this.display();
			System.out.println("Inner Class x="+x);
		}
		
	}
	
	//Outer Class Display Function
	public void display()
	{
		
		class LocalInnerClass
		{
			
		}
		System.out.println("Outer Class x="+OuterClass.this.x);
	}
	
	
	

}
