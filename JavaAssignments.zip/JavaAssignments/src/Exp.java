
public class Exp {
	 public static String check() {
	        
	        try {
	            
	            int a=10/0;
	            if(a==0) {
	                return "true";
	            }
	            else
	                return "false";
	            
	        }
	        catch(Exception e) {
	            return "Eception Occured";
	        }
	        finally {
	            String s ="aman";
	            return s;
	        }
	        
	    
	    }
	    
	    
	    public static void main(String[] args) {
	        
	        
	        System.out.println(check());
	        
	    }
	}


