
public class Exception1Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int arr[]= {20,30};
		String str=""+arr[0];
		int x=Integer.parseInt(str);
		System.out.println(x);
		System.out.println(str.substring(2,5));
		
		}
		catch(NumberFormatException ex)
		{
			System.out.println("Number Should Be in Numerical Format");
		}
		catch(ArrayIndexOutOfBoundsException ex)
		{
			System.out.println("Number Should Be in Numerical Format");
		}
		catch(StringIndexOutOfBoundsException ex)
		{
			System.out.println("Number Should Be in Numerical Format");
			
		}
		catch(IndexOutOfBoundsException ex)
		{
			System.out.println("Number Should Be in Numerical Format");
		}
		catch(Exception ex)
		{
			System.out.println("Number Should Be in Numerical Format");
		}
		finally
		{
			System.out.println("Finally");
		}
		
		

	}

}
