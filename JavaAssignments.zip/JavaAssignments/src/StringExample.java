//Sequence of charater

public class StringExample {
	
	public static void main(String[] args) {
		
				String str="hello elo"; //Liertal Object
				String str1=new String("Hello");
				String str2="Hello";
				String str3=new String("Hello");
				
				System.out.println(str==str1); //False
				System.out.println(str.equals(str1)); //true
				
				System.out.println(str==str2); //true
				System.out.println(str.equals(str2)); //true
				
				System.out.println(str==str3);//false
				
				System.out.println(str1==str3);
				
				System.out.println(str.charAt(0));
				for(int i=0;i<str.length();i++)
				System.out.println(str.charAt(i));
				
				
				System.out.println(str1.compareToIgnoreCase(str));
				str1=str1.concat(str);
				System.out.println(str1.indexOf("el",3));
				System.out.println(str1.lastIndexOf("el"));
				
				String pp="dfsf";
				//pp=null;
				System.out.println(pp.isEmpty());
				
				String data=" I Love India ".trim();
				String dataSplit[]=data.split(" ");
				
				boolean var=false;
				String ss=String.valueOf(var);
				
				
				StringBuffer br=new StringBuffer();
				br.append("Hello");
				br.append(" ");
				br.append("World");
				System.out.println(br.toString());
				
				
				
				
		
	}

}
