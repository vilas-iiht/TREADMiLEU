interface Shape
{
	void draw();
}



public class AnnoClassExample {
	
	public static void main(String[] args) {
		
		(new Shape() {

			@Override
			public void draw() {
				// TODO Auto-generated method stub
				System.out.println("Any Thing");
			}
			
			
		}).draw();;
		
	}

}
