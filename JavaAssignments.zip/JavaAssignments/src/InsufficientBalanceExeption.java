
public class InsufficientBalanceExeption extends RuntimeException{
	
	String msg;
	public InsufficientBalanceExeption(String msg)
	{
		this.msg=msg;
	}
	
	public String getMessage()
	{
		return msg;
	}

}
