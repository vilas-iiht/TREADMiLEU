
public class SalesManager extends Manager{
	
private double amounTOfProductSale;
private int salesPer;
private double totalComm;
	

	public SalesManager() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public SalesManager(int empno, String name, double sal,double amounTOfProductSale,int salesPer,double totalComm) {
		super(empno,name,sal,totalComm);
		
		// TODO Auto-generated constructor stub
	}	
	
	@Override
	public String toString() {
		return super.toString()+" Comm="+getComm();
	}
	

}